const middleware = {}

middleware['visit'] = require('../middleware/visit.js')
middleware['visit'] = middleware['visit'].default || middleware['visit']

export default middleware
