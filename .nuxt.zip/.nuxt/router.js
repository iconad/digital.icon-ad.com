import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _da757a9a = () => interopDefault(import('../pages/about.vue' /* webpackChunkName: "pages/about" */))
const _42242441 = () => interopDefault(import('../pages/digital/index.vue' /* webpackChunkName: "pages/digital/index" */))
const _8a3233d8 = () => interopDefault(import('../pages/icon-plus.vue' /* webpackChunkName: "pages/icon-plus" */))
const _18fe33b0 = () => interopDefault(import('../pages/services.vue' /* webpackChunkName: "pages/services" */))
const _8200174a = () => interopDefault(import('../pages/work.vue' /* webpackChunkName: "pages/work" */))
const _4a812294 = () => interopDefault(import('../pages/digital/one-two.vue' /* webpackChunkName: "pages/digital/one-two" */))
const _9b05c510 = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about",
    component: _da757a9a,
    name: "about"
  }, {
    path: "/digital",
    component: _42242441,
    name: "digital"
  }, {
    path: "/icon-plus",
    component: _8a3233d8,
    name: "icon-plus"
  }, {
    path: "/services",
    component: _18fe33b0,
    name: "services"
  }, {
    path: "/work",
    component: _8200174a,
    name: "work"
  }, {
    path: "/digital/one-two",
    component: _4a812294,
    name: "digital-one-two"
  }, {
    path: "/",
    component: _9b05c510,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
